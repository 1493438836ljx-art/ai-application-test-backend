#!/usr/bin/env python3
import argparse
import time

def main():
    time.sleep(15)

    parser = argparse.ArgumentParser(description='计算两个数的和')
    parser.add_argument('a', type=float, help='第一个数')
    parser.add_argument('b', type=float, help='第二个数')
    args = parser.parse_args()

    result = args.a + args.b
    print(f"sum: {result}")


if __name__ == '__main__':
    main()
